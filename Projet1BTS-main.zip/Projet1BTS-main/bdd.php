<?php
 $idc = mysqli_connect("localhost", "root", "", "resa");
 ?>